package com.leanproject.igsocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IgsocialApplication {

	public static void main(String[] args) {
		SpringApplication.run(IgsocialApplication.class, args);
	}

}
